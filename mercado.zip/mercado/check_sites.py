#!/usr/bin/env python
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
django.setup()

from django.contrib.sites.models import Site
from allauth.socialaccount.models import SocialApp

print('=== SITES EN LA BD ===')
for s in Site.objects.all():
    print(f"  ID: {s.id}, Domain: {s.domain}")

print('\n=== APPS OAUTH ===')
for a in SocialApp.objects.all():
    sites = list(a.sites.values_list('id', flat=True))
    print(f"  ID: {a.id}, Provider: {a.provider}, Sites: {sites}")

print('\n=== PROBLEMA ===')
# Si hay múltiples sites, Django Allauth se confunde
if Site.objects.count() > 1:
    print("⚠️  HAY MÚLTIPLES SITES! Esta es la causa del error.")
    print("Eliminando todos excepto SITE_ID=1...")
    for site in Site.objects.exclude(pk=1):
        print(f"  - Eliminando site ID={site.id}: {site.domain}")
        site.delete()
else:
    print("✓ Solo 1 sitio (correcto)")

print('\n=== DESPUÉS DE LIMPIAR ===')
for a in SocialApp.objects.all():
    sites = list(a.sites.values_list('id', flat=True))
    print(f"  {a.provider}: sites={sites}")
