#!/usr/bin/env python
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
django.setup()

from allauth.socialaccount.models import SocialApp
from django.contrib.sites.models import Site

print("=" * 70)
print("RECREANDO APLICACIONES OAUTH")
print("=" * 70)

# Obtener el sitio
site = Site.objects.get(pk=1)
print(f"\n✓ Usando sitio: {site.domain}")

# Eliminar apps antiguas
print("\n📍 Eliminando apps antiguas...")
deleted_count, _ = SocialApp.objects.all().delete()
print(f"   Eliminadas: {deleted_count} apps")

# Leer credenciales desde .env
from django.conf import settings
import environ

env = environ.Env()
environ.Env.read_env(os.path.join(os.path.dirname(__file__), '.env'))

google_id = env('GOOGLE_OAUTH_CLIENT_ID', default='')
google_secret = env('GOOGLE_OAUTH_CLIENT_SECRET', default='')
github_id = env('GITHUB_OAUTH_CLIENT_ID', default='')
github_secret = env('GITHUB_OAUTH_CLIENT_SECRET', default='')

print("\n📍 Credenciales cargadas:")
print(f"   Google ID: {google_id[:30]}..." if google_id else "   Google ID: NO CONFIGURADO")
print(f"   Google Secret: {'✓ Presente' if google_secret else '✗ FALTA'}")
print(f"   GitHub ID: {github_id[:20]}..." if github_id else "   GitHub ID: NO CONFIGURADO")
print(f"   GitHub Secret: {'✓ Presente' if github_secret else '✗ FALTA'}")

if not all([google_id, google_secret, github_id, github_secret]):
    print("\n❌ ERROR: Faltan credenciales en .env")
    print("   Actualiza mercado/.env con tus credenciales OAuth")
    exit(1)

# Crear apps
print("\n📍 Creando nuevas apps...")

google_app = SocialApp.objects.create(
    provider='google',
    name='Google',
    client_id=google_id,
    secret=google_secret,
)
google_app.sites.add(site)
print(f"   ✓ Google creado (ID={google_app.id})")

github_app = SocialApp.objects.create(
    provider='github',
    name='GitHub',
    client_id=github_id,
    secret=github_secret,
)
github_app.sites.add(site)
print(f"   ✓ GitHub creado (ID={github_app.id})")

# Verificación
print("\n✓ VERIFICACIÓN FINAL:")
for app in SocialApp.objects.all():
    sites = list(app.sites.values_list('domain', flat=True))
    print(f"  {app.provider.upper()}: {sites}")

print("\n" + "=" * 70)
print("✅ LISTO. Las apps OAuth han sido recreadas correctamente.")
print("=" * 70)
