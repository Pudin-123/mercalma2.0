#!/usr/bin/env python
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
django.setup()

from allauth.socialaccount.models import SocialApp
from django.contrib.sites.models import Site

print('=== LIMPIEZA COMPLETA ===')

# Paso 1: Eliminar todos los SocialApp
print("\n1. Eliminando SocialApps...")
deleted, _ = SocialApp.objects.all().delete()
print(f"   Eliminados: {deleted}")

# Paso 2: Crear nuevamente
print("\n2. Creando nuevas apps...")
site = Site.objects.get(pk=1)

google = SocialApp.objects.create(
    provider='google',
    name='Google',
    client_id=os.environ.get('GOOGLE_OAUTH_CLIENT_ID', ''),
    secret=os.environ.get('GOOGLE_OAUTH_CLIENT_SECRET', ''),
)
google.sites.add(site)
print(f"   ✓ Google: {google.id}")

github = SocialApp.objects.create(
    provider='github',
    name='GitHub',
    client_id=os.environ.get('GITHUB_OAUTH_CLIENT_ID', ''),
    secret=os.environ.get('GITHUB_OAUTH_CLIENT_SECRET', ''),
)
github.sites.add(site)
print(f"   ✓ GitHub: {github.id}")

print('\n3. Verificación:')
for app in SocialApp.objects.all():
    sites = list(app.sites.values_list('domain', flat=True))
    print(f"   {app.provider} (ID={app.id}): {sites}")
