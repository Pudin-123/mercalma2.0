#!/usr/bin/env python
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
django.setup()

from django.contrib.sites.models import Site
from allauth.socialaccount.models import SocialApp

print("=" * 60)
print("VERIFICACIÓN DE CONFIGURACIÓN OAUTH")
print("=" * 60)

# 1. Sitio actual
site = Site.objects.get(pk=1)
print(f"\n✓ Sitio actual: {site.domain}")
print(f"  Callback base: http://{site.domain}")

# 2. Verificar apps
print(f"\n✓ Apps OAuth registradas:")
for app in SocialApp.objects.all():
    print(f"  - {app.provider.upper()}")
    print(f"    Name: {app.name}")
    print(f"    Client ID: {app.client_id[:20]}...")
    print(f"    Has Secret: {'YES' if app.secret else 'NO'}")
    print(f"    Linked to sites: {list(app.sites.values_list('domain', flat=True))}")

# 3. URLs de callback
print(f"\n✓ URLs DE CALLBACK ESPERADAS:")
print(f"  Google: http://{site.domain}/accounts/google/login/callback/")
print(f"  GitHub: http://{site.domain}/accounts/github/login/callback/")

print("\n" + "=" * 60)
print("PRÓXIMO PASO:")
print("=" * 60)
print("""
1. Ve a Google Cloud Console
2. En Credenciales → OAuth 2.0 Client ID
3. En "URIs de redireccionamiento autorizados" asegúrate de tener:
   - http://127.0.0.1:8000/accounts/google/login/callback/
4. Haz lo mismo para GitHub en Developer Settings
5. Guarda y prueba nuevamente
""")
