

// small future JS namespace
console.log('MERCALMA v2 frontend loaded');

