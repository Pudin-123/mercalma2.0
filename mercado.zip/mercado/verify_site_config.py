#!/usr/bin/env python
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
django.setup()

from django.contrib.sites.models import Site
from allauth.socialaccount.models import SocialApp

print("=== Verificación de Sites ===")
sites = Site.objects.all()
for site in sites:
    print(f"  ID {site.id}: {site.domain} - {site.name}")

print("\n=== Verificación de Social Apps ===")
for app in SocialApp.objects.all():
    sites_list = list(app.sites.values_list('domain', flat=True))
    print(f"  {app.provider}:")
    print(f"    - Client ID: {app.client_id[:30]}...")
    print(f"    - Secret: {'*' * 10}")
    print(f"    - Sites: {sites_list}")
