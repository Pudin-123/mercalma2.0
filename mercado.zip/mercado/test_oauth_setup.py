#!/usr/bin/env python
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
django.setup()

from allauth.socialaccount.adapter import DefaultSocialAccountAdapter
from django.contrib.sites.models import Site

# Simular lo que ocurre cuando se accede a /accounts/google/login/
print("=== Simulando acceso a /accounts/google/login/ ===\n")

try:
    # Este es el código que falla en el error original
    from allauth.socialaccount.models import SocialApp
    
    # Obtener el sitio actual (SITE_ID = 1)
    site = Site.objects.get(pk=1)
    print(f"Sitio actual (SITE_ID=1): {site.domain}")
    
    # Intentar obtener la app de Google
    google_app = SocialApp.objects.get(provider='google', sites__id__exact=1)
    print(f"\n✓ App de Google encontrada!")
    print(f"  - Provider: {google_app.provider}")
    print(f"  - Name: {google_app.name}")
    print(f"  - Client ID: {google_app.client_id[:30]}...")
    print(f"  - Vinculado a sitios: {list(google_app.sites.values_list('domain', flat=True))}")
    
    # Intentar obtener la app de GitHub
    github_app = SocialApp.objects.get(provider='github', sites__id__exact=1)
    print(f"\n✓ App de GitHub encontrada!")
    print(f"  - Provider: {github_app.provider}")
    print(f"  - Name: {github_app.name}")
    print(f"  - Client ID: {github_app.client_id[:30]}...")
    print(f"  - Vinculado a sitios: {list(github_app.sites.values_list('domain', flat=True))}")
    
    print(f"\n✅ Todo está configurado correctamente. Ahora puedes acceder a:")
    print(f"   - http://127.0.0.1:8000/accounts/google/login/")
    print(f"   - http://127.0.0.1:8000/accounts/github/login/")
    
except SocialApp.DoesNotExist as e:
    print(f"\n❌ Error: {e}")
    print(f"Verifica que las apps estén registradas en Django Admin")
