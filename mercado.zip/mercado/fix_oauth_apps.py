#!/usr/bin/env python
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
django.setup()

from allauth.socialaccount.models import SocialApp
from django.contrib.sites.models import Site

# Obtener o crear el sitio
site = Site.objects.get(pk=1)
print(f"Sitio: {site.domain}")

# Eliminar todas las apps sociales actuales (para limpiar)
print("\n=== Eliminando apps antiguas ===")
for app in SocialApp.objects.all():
    print(f"  - Eliminando {app.provider} ({app.name})")
    app.delete()

# Recrear las apps desde cero
print("\n=== Creando apps nuevas ===")

# Google
google_app = SocialApp.objects.create(
    provider='google',
    name='Google',
    client_id=os.environ.get('GOOGLE_OAUTH_CLIENT_ID', ''),
    secret=os.environ.get('GOOGLE_OAUTH_CLIENT_SECRET', ''),
)
google_app.sites.add(site)
print(f"  ✓ Google creado (ID: {google_app.client_id[:20]}...)")

# GitHub
github_app = SocialApp.objects.create(
    provider='github',
    name='GitHub',
    client_id=os.environ.get('GITHUB_OAUTH_CLIENT_ID', ''),
    secret=os.environ.get('GITHUB_OAUTH_CLIENT_SECRET', ''),
)
github_app.sites.add(site)
print(f"  ✓ GitHub creado (ID: {github_app.client_id[:20]}...)")

print("\n=== Verificación final ===")
for app in SocialApp.objects.all():
    sites = list(app.sites.values_list('domain', flat=True))
    print(f"  {app.provider}: {sites}")
