#!/usr/bin/env python
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
django.setup()

from allauth.socialaccount.models import SocialApp
from django.contrib.sites.models import Site

print("=== SITES DISPONIBLES ===")
for site in Site.objects.all():
    print(f"  ID: {site.id}, Domain: {site.domain}, Name: {site.name}")

print("\n=== APLICACIONES OAUTH ===")
for app in SocialApp.objects.all():
    sites = list(app.sites.values_list('domain', flat=True))
    print(f"  ID: {app.id}, Provider: {app.provider}, Name: {app.name}")
    print(f"    Sites vinculados: {sites}")
    print(f"    Client ID: {'✓' if app.client_id else '✗'}")
    print(f"    Secret: {'✓' if app.secret else '✗'}")

print("\n=== VERIFICACIÓN ===")
# Contar por proveedor
from django.db.models import Count
provider_counts = SocialApp.objects.values('provider').annotate(count=Count('id'))
for item in provider_counts:
    print(f"  Proveedor '{item['provider']}': {item['count']} apps")
