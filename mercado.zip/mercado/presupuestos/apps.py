from django.apps import AppConfig


class PresupuestosConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'presupuestos'
