#!/usr/bin/env python
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
django.setup()

from allauth.socialaccount.models import SocialApp
from django.contrib.sites.models import Site

# Verificar/crear sitios
print("=== Configurando Sites ===")
site_127, created = Site.objects.get_or_create(
    pk=1,
    defaults={'domain': '127.0.0.1:8000', 'name': '127.0.0.1:8000'}
)
if created:
    print(f"  ✓ Creado sitio: {site_127.domain}")
else:
    print(f"  ✓ Sitio existente: {site_127.domain}")

# Asegurarse de que las apps OAuth están vinculadas al sitio correcto
print("\n=== Actualizando Social Apps ===")

# Google
try:
    google_app = SocialApp.objects.get(provider='google')
    print(f"  Google encontrado, actualizando...")
    
    # Limpiar sitios existentes
    google_app.sites.clear()
    # Agregar el sitio correcto
    google_app.sites.add(site_127)
    
    print(f"    ✓ Client ID: {google_app.client_id[:20]}...")
    print(f"    ✓ Sites: {list(google_app.sites.values_list('domain', flat=True))}")
except SocialApp.DoesNotExist:
    print(f"  ! Google no encontrado, creando...")
    google_app = SocialApp.objects.create(
        provider='google',
        name='Google',
        client_id=os.environ.get('GOOGLE_OAUTH_CLIENT_ID', ''),
        secret=os.environ.get('GOOGLE_OAUTH_CLIENT_SECRET', ''),
    )
    google_app.sites.add(site_127)
    print(f"    ✓ Google creado y vinculado")

# GitHub
try:
    github_app = SocialApp.objects.get(provider='github')
    print(f"  GitHub encontrado, actualizando...")
    
    # Limpiar sitios existentes
    github_app.sites.clear()
    # Agregar el sitio correcto
    github_app.sites.add(site_127)
    
    print(f"    ✓ Client ID: {github_app.client_id[:20]}...")
    print(f"    ✓ Sites: {list(github_app.sites.values_list('domain', flat=True))}")
except SocialApp.DoesNotExist:
    print(f"  ! GitHub no encontrado, creando...")
    github_app = SocialApp.objects.create(
        provider='github',
        name='GitHub',
        client_id=os.environ.get('GITHUB_OAUTH_CLIENT_ID', ''),
        secret=os.environ.get('GITHUB_OAUTH_CLIENT_SECRET', ''),
    )
    github_app.sites.add(site_127)
    print(f"    ✓ GitHub creado y vinculado")

print("\n=== Verificación final ===")
for app in SocialApp.objects.all():
    sites_list = list(app.sites.values_list('domain', flat=True))
    print(f"  {app.provider}: {sites_list}")
    if not sites_list:
        print(f"    ! ADVERTENCIA: {app.provider} no tiene sitios vinculados!")
